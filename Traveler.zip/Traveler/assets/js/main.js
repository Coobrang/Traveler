// Mobile Menu
console.clear();

const navExpand = document.querySelectorAll('.nav-expand');
const backLink = `<li class="nav-item"><a href="javascript:;" class="nav-link nav-back-link"><i class="fa-solid fa-caret-left"></i></a></li>`

navExpand.forEach(item => {
    item.querySelector('.nav-expand-content').insertAdjacentHTML('afterbegin', backLink);
    item.querySelector('.nav-link').addEventListener('click', () => item.classList.toggle('active'));
    item.querySelector('.nav-back-link').addEventListener('click', () => item.classList.remove('active'));
});

document.getElementById('ham').addEventListener('click', () => document.body.classList.toggle('nav-is-toggled'));

// Search
let container = document.getElementById("select");
let list = container.querySelector("#list");
let inputField = container.querySelector("input[name='location_name']");

container.onclick = function () {
    list.classList.toggle("open");
};

list.addEventListener("click", function (event) {
    if (event.target.classList.contains("options")) {
        inputField.placeholder = event.target.innerHTML;
        list.classList.remove("open");
        event.stopPropagation();
    }
});

function increaseNumber() {
    var input = document.getElementById('number');
    var currentValue = parseInt(input.value, 10);
    input.value = currentValue + 1;
}

function decreaseNumber() {
    var input = document.getElementById('number');
    var currentValue = parseInt(input.value, 10);
    if (currentValue > 1) {
        input.value = currentValue - 1;
    }
}